# ADI Research Series Paper 5

## The Continuity Substrate

### A Controlled Test of Deterministic Governed Memory Across Models, Clients, and Runtime Restarts

Branden Laskowski · Cortex Agentics Global  
Preprint · 5 November 2026

Paper 5 begins with one scientific question:

> When the model, client, machine, or runtime changes, can one governed memory substrate preserve the exact continuity of work without transferring authority over memory to the replacement model?

The paper answers with one controlled replacement test. It freezes a continuity state and its governing contract, replaces the reasoning and access components around it, and measures whether the state, exact provenance, scope, lifecycle, and receipts remain invariant with zero unauthorized effects. Model comprehension is scored separately.

This is an empirical extension of Branden Laskowski's Artificial Deterministic Intelligence (ADI) research program. ADI supplies the theory—probabilistic reasoning, deterministic authority—and Cortex Continuum is the evaluated memory substrate. Cite the ADI umbrella paper through its version DOI: [10.5281/zenodo.23265200](https://doi.org/10.5281/zenodo.23265200).

The current record supports this bounded statement:

> In controlled first-party synthetic tests, Cortex Continuum preserved the tested operational continuity state across named model, client, machine, operating-system, and runtime replacements while canonical authority remained outside model inference.

The record does not establish universal model compatibility, complete hosted-provider portability, production readiness, security certification, or independent replication.

## Public verification package

- [Rendered preprint](ADI_Paper_5_The_Continuity_Substrate_Preprint.pdf)
- [Manuscript](MANUSCRIPT.md)
- [Public evidence summary](PUBLIC_EVIDENCE_SUMMARY.md)
- [Cortex Continuum Benchmark v1](BENCHMARK.md)
- [Deposit metadata](METADATA.json)
- [Citation metadata](CITATION.cff)
- [Public artifact hashes](SHA256SUMS)
- [Model-consumption fixture](reproducibility/model-consumption-fixture.json)
- [Reference scorer](reproducibility/score-model-response.mjs)
- [Expected passing response](reproducibility/expected-pass-response.json)
- [Cortex Governed Memory Challenge](../../challenges/governed-memory/README.md)

The existing challenge supplies the symbolic governed-memory contract, 12 synthetic fixtures, schema, scoring rules, reference client, API, examples, and lifecycle limits. The Paper 5 companion fixture supplies the separate read-only model-consumption contract. Reviewers can test both layers without access to the proprietary kernel.

Live endpoint availability is controlled by the challenge status document. If an authorized endpoint is unavailable, a new live result is `NOT_TESTED`; historical results must not be presented as a new run.

## Disclosure boundary

This branch contains research prose, synthetic fixtures, a public scorer, and bounded evidence summaries. It does not disclose proprietary subsystem names, internal role labels, implementation topology, source code for the private kernel, private records, credentials, or production deployment details.
