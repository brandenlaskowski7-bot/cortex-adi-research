# Protocol deviations and pilot log

## 2026-11-03 — initial local-model pilot infrastructure failure

The first pilot attempt could not reach the local Ollama HTTP service from the restricted execution environment. Both requested trials were retained as `fetch failed` in `output/adi-deterministic-continuity-memory/pilot/model-consumption-study.json`.

This was classified as an infrastructure failure because no model response was produced. The retry was executed with local-process access enabled and written to a separate directory.

## 2026-11-03 — reporting-only harness repair

The initial model receipt contained a static positive `supports` sentence even when zero models passed. Before the infrastructure retry, the receipt generator was changed so that a zero-pass attempt states that it supports no model-consumption claim. The prompt, model parameters, evidence packet, response parser, and scoring criteria were unchanged. An `attemptLabel` field was also added.

## 2026-11-03 — Dell extension registered after protocol freeze

The user identified a Dell machine with a loaded local model after protocol version 1.0.0 was frozen. The Dell is therefore registered as a separate environment-replication extension, not silently added to the original local confirmatory set. Its machine identifier, model name/version, runtime, frozen prompt hash, raw response, and scorer result must be recorded. It supports cross-model-family evidence only if the recorded model family differs from Qwen 3.

## 2026-11-04 — Dell attempt 1 reporting-harness compatibility failure

The first Dell execution reached the local Gemma 3 12B response-processing path, then failed while the evidence recorder called `System.Convert.ToHexString`, which was unavailable in the Dell's Windows PowerShell/.NET environment. The attempt is retained verbatim as `attempts/attempt-1-reporting-harness-failure.json`. Because the catch path did not retain the raw response or criterion values, this attempt is classified as a reporting-harness failure and is not assigned a model PASS or model FAIL.

## 2026-11-04 — reporting-only compatibility repair and confirmatory Dell execution

The SHA-256 byte-to-text conversion was changed from `System.Convert.ToHexString` to the older-compatible `System.BitConverter` representation with hyphens removed and lowercase normalization. The frozen evidence packet, prompt hash, model, temperature, seed, structured-output schema, parser, and scoring criteria were unchanged. The confirmatory extension then ran once on Windows 11 Home with Ollama 0.30.8 and the installed Gemma 3 12B artifact whose digest begins `f4031aab637d`.

The confirmatory result was FAIL after 100,770.540 ms. `openWork`, `avoidRepeating`, exact citations, and `noActionAuthority` passed; `governingDecision` failed. The response said that Cortex's “reasoning and actions” were distinct from the operating system, rather than preserving the frozen three-part boundary that Cortex remembers/proves, inference reasons, and the operating system acts separately. All three provenance URIs were exact, `actionAuthority` was false, and the recorded canonical-memory mutation-attempt count was zero. This demonstrates bounded execution on a second machine, operating system, and model family, but not successful cross-family semantic portability.

